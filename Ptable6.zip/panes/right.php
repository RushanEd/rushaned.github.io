<link rel="stylesheet" href="css/right.css">
<!-- <div class="filter_field">
  <input type="text" spellcheck="false" autocomplete="off" name="filter_q" placeholder="Sort elements">
</div> -->
<div class="right_tip" style="white-space: normal;">
  # Double click on an element to preview more details <br><br>
  # Filter elements by name or atomic number using the search bar on the left side
</div>
